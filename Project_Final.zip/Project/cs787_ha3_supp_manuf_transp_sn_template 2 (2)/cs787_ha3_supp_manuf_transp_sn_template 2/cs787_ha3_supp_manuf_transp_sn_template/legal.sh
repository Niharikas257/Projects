python solution/main.py < project/legal.json > answers/legal_output.json
python solution/optLegal.py
python solution/filterLegal.py