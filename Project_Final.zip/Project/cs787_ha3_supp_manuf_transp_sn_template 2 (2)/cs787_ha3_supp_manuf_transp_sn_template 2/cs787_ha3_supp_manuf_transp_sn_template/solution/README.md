Run the following commands to run individual files and uncomment the answer in main.py to the desired function you want to run 



for legal file:


python solution/main.py < project/legal.json > answers/legal_output.json
python solution/optLegal.py
python solution/filterLegal.py


for finance file:


python solution/main.py < project/finance.json > answers/finance_output.json
python solution/optFinance.py
python solution/filterFinance.py


for developer file:

python solution/main.py < project/developer.json > answers/developer_output.json
python solution/optEngineering.py
python solution/filterEngineering.py


for infrastructure file:

python solution/main.py < project/infrastructure.json > answers/infrastructure_output.json
python solution/optInfrastructure.py
python solution/filterInfrastructure.py


for marketing file:


python solution/main.py < project/marketing.json > answers/marketing_output.json
python solution/optMarketing.py
python solution/filterMarketing.py