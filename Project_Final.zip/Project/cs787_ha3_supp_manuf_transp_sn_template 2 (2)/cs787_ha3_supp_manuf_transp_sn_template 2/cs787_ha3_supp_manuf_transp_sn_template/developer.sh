python solution/main.py < project/developer.json > answers/developer_output.json
python solution/optEngineering.py
python solution/filterEngineering.py